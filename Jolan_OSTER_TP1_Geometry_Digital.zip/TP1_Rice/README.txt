cd build
cmake ..
make

./main ../RiceGrains/Rice_basmati_seg_bin.pgm 
./main ../RiceGrains/Rice_camargue_seg_bin.pgm 
./main ../RiceGrains/Rice_japonais_seg_bin.pgm 